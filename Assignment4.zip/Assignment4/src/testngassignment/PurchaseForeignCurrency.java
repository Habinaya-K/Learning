package testngassignment;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PurchaseForeignCurrency {
	
		public WebDriver driver;
		
	    @BeforeTest
		public void setUp() {
		//Set system path for browser driver 
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//to open browser
        System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");		
		driver = new ChromeDriver();		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.get("http://zero.webappsecurity.com/index.html");
		}
		
		@Test (groups= {"smoke"})
		
	    public void foeignCurrency() {

		//1. Purchase Foreign currency
		driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.id("user_login")).sendKeys("username");
		driver.findElement(By.id("user_password")).sendKeys("password");
		driver.findElement(By.name("submit")).click();
		
		//To accept the privacy
        driver.findElement(By.id("details-button")).click();
        driver.findElement(By.id("proceed-link")).click();
        
        //Navigate to Purchase Foreign currency
        driver.findElement(By.linkText("Pay Bills")).click();
        driver.findElement(By.linkText("Purchase Foreign Currency")).click();
        
        //Explicit Wait
        WebDriverWait payWait = new WebDriverWait(driver,10);
        payWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[contains(text(),'Purchase foreign currency cash')]")));	
        
        //Handling alert
        driver.findElement(By.xpath("//input[@value='Purchase']")).click();
    	Alert purchase = driver.switchTo().alert();
		String foreign = purchase.getText();
		assertEquals(foreign,"Please, ensure that you have filled all the required fields with valid values.");
		purchase.accept();
		}
        
		
	    @AfterTest
	    public void cleanUp() {
	        driver.findElement(By.cssSelector("i.icon-user")).click();
	        driver.findElement(By.id("logout_link")).click();
	        System.out.println("Signed out successfully");
	        
	        driver.close();
	        driver.quit();
	}

}
