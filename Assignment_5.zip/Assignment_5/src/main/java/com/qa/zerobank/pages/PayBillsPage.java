package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qa.zerobank.base.BaseTest;

public class PayBillsPage extends BaseTest{
	@FindBy(partialLinkText  = "Purchase Foreign Cur")
	WebElement Purchase_Foreign_Currency_Tab;
	
	@FindBy(xpath  = "//h2[text()='Make payments to your saved payees']")
	WebElement Make_payments_to_your_saved_payees_txt;
	
	@FindBy(xpath  = "//h2[text()='Purchase foreign currency cash']")
	WebElement Purchase_foreign_currency_cash_txt;
	
	@FindBy(xpath  = "//input[@value='Purchase']")
	WebElement Purchase_btn;
	
	@FindBy(linkText =  "Transfer Funds")
	WebElement TransferFunds;
	@FindBy(partialLinkText  =  "Pay Saved Payee")
	WebElement paysavepayee;
	@FindBy(xpath  =  "//input[@value='Pay']")
	WebElement pay_btn;
	@FindBy(xpath = "//h2[text()='Make payments to your saved payees']")
	WebElement MakePaymetTxt;
	@FindBy(xpath = "//div[@class='controls']//input")
	WebElement Input1;
	@FindBy(xpath = "(//div[@class='controls']//input)[3]")
	WebElement Input2;

	// constructor
	public PayBillsPage() {
		PageFactory.initElements(driver, this);
	}

	// assert title
	public void assertPayBillsPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Pay Bills");
	}
	public void Click_Purchase_Foreign_Currency_Tab() {
		Purchase_Foreign_Currency_Tab.click();
		
	}
	
	public void PurchaseForeignCurrencySection() {
		
		Purchase_btn.click();
		
	}
	public void PurchaseForeignCurrency_Alert() {
		
		String alert = driver.switchTo().alert().getText();
		Assert.assertEquals(alert, "Please, ensure that you have filled all the required fields with valid values.",
				"Alert text is not matching");
		System.out.println(alert);
		driver.switchTo().alert().accept();

	}
	public void NegativePaySavedPayee() {
		
		
		paysavepayee.click();
		Input1.sendKeys(prop.getProperty("Amount"));
		Input2.sendKeys(prop.getProperty("Desc"));
		pay_btn.click();
		String Text = MakePaymetTxt.getText();
		Assert.assertEquals(Text, "Make payments to your saved payees");
		
	}
	public TransferFundsPage NavigateTransferFunds() {


		TransferFunds.click();
		
		return new TransferFundsPage();
		}
}
