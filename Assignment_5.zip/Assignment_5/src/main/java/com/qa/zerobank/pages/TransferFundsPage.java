package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.qa.zerobank.base.BaseTest;

public class TransferFundsPage extends BaseTest {
	@FindBy(id ="fromAccountId")
	WebElement fromAccount;
	
	@FindBy(id ="tf_toAccountId")
	WebElement toAccount;
	
	@FindBy(id ="tf_amount")
	WebElement amount;
	
	@FindBy(id ="tf_description")
	WebElement description;
	
	@FindBy(id ="btn_submit")
	WebElement continue_Btn;
	
	@FindBy(xpath ="//button[@type='submit']")
	WebElement submit_Btn;
	
	@FindBy(xpath ="//div[@class='alert alert-success']")
	WebElement SuccessMsg;
	
	@FindBy(xpath ="//h2[text()='Transfer Money & Make Payments']")
	WebElement TransferMoneyTxt;
	
	public TransferFundsPage() {

		PageFactory.initElements(driver, this);

	}

	public void assertHomePageTitle() {

		assertEquals(driver.getTitle(), "Zero - Transfer Funds", "Mismatch found");

	}
	
	public void ValidateTransferMoneyAndMakePayments() {
		WebElement fromAccountId = driver.findElement(By.name("fromAccountId"));
		Select select = new Select(fromAccountId);
		select.selectByValue("2");
		WebElement To = driver.findElement(By.id("tf_toAccountId"));
		Select sel2 = new Select(To);
		sel2.selectByVisibleText("Credit Card(Avail. balance = $ -265)");
		amount.sendKeys(prop.getProperty("Amount"));
		description.sendKeys(prop.getProperty("Desc"));
		continue_Btn.click();
		submit_Btn.click();
		String text = SuccessMsg.getText();
		Assert.assertEquals(text, "You successfully submitted your transaction.", "The displayed text is not matching");
	}
	public void InvalidateTransferMoneyAndMakePayments() {
		WebElement fromAccountId = driver.findElement(By.name("fromAccountId"));
		Select select = new Select(fromAccountId);
		select.selectByValue("2");
		WebElement To = driver.findElement(By.id("tf_toAccountId"));
		Select sel2 = new Select(To);
		sel2.selectByVisibleText("Credit Card(Avail. balance = $ -265)");
		description.sendKeys(prop.getProperty("Desc"));
		continue_Btn.click();
		submit_Btn.click();
		String Text = driver.findElement(By.xpath("//h2[text()='Transfer Money & Make Payments']")).getText();
		Assert.assertEquals(Text, "Transfer Money & Make Payments");
	}
}
