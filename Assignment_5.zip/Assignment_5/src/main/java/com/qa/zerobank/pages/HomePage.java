package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.mysql.cj.x.protobuf.MysqlxExpect.Open.Condition.Key;
import com.qa.zerobank.base.BaseTest;

public class HomePage extends BaseTest  {

	@FindBy(id="signin_button")
	WebElement signInButton;

	@FindBy(name="searchTerm")
	WebElement searchBox;

	@FindBy(linkText="Zero Bank")
	WebElement pageTitle;

	@FindBy(id="onlineBankingMenu")
	WebElement onlineBanking;

	@FindBy(id="feedback")
	WebElement feedBack;

	@FindBy(xpath="//a[contains(text(),'�')]")
	WebElement leftArrowButton;

	@FindBy(xpath="//a[contains(text(),'�')]")
	WebElement rightArrowButton;

	@FindBy(xpath="//a[@href='/index.html']")
	WebElement logo;

	@FindBy(id="online-banking")
	WebElement onlineBankingButton;

	@FindBy(id="account_activity_link")
	WebElement accountActivity;

	@FindBy(id="transfer_funds_link")
	WebElement transferFund;

	@FindBy(id="money_map_link")
	WebElement moneyMap;

	@FindBy(xpath="//a[contains(@href,'/about/legal/#privacy')][1]")
	WebElement privacyLink1;

	@FindBy(xpath="//a[contains(@href,'/about/legal/#privacy')][2]")
	WebElement privacyLink2;
	
	@FindBy(xpath="//div[@class='top_offset']//a[1]")
	WebElement LinkAfterSearch;
	
	public HomePage() {


		PageFactory.initElements(driver, this);

		}

		public void assertHomePageTitle() {

		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Mismatch found");

		}
		
		public boolean VerifyLogo() {
			return logo.isDisplayed();
		}
		public LogInPage clickOnSignInButton() {
			
			signInButton.click();
			return new LogInPage();
		}
		public SearchResultPage enterOnSearchBox(String searchData) {
			searchBox.click();
			searchBox.sendKeys(searchData);
			searchBox.sendKeys(Keys.ENTER);
			return new SearchResultPage();
			}
}
