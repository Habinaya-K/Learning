package com.qa.orange.testcases;



import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.orange.base.BaseTest;
import com.qa.orange.pages.Candidate;
import com.qa.orange.pages.HomePage;
import com.qa.orange.pages.LogInPage;
import com.qa.orange.util.Testutil;
/**
 * @author Vishnu Raj
 *
 */
public class Assignment5_Testcases extends BaseTest {
	HomePage homepage;
	LogInPage loginpage;
	Candidate candidate;
	String path = System.getProperty("user.dir") + "\\src\\main\\java\\com\\qa\\orange\\testdata\\";
	String name = "Test_Data.xlsx";
	String Sheetname= "LogIn";
	public Assignment5_Testcases() {
		super();

	}
	/**
	 * initialization of driver from base class
	 *
	 */
	@BeforeTest
	public void setup() {
		initialization();
		homepage = new HomePage();
		loginpage = new LogInPage();
		candidate = new Candidate();
		
		
	}
	/**
	 * Kill the driver
	 *
	 */
	@AfterTest
	public void quit() {
		Testutil.TakeScreenshot("Close");
		driver.close();
		driver.quit();

	}
	/**
	 * Verify the logo and home page
	 *
	 */
	@Test(priority = 1)
	public void ValidateLoginPage() {
		loginpage.assertLoginPageTitle();
		loginpage.UsernamePassword();
		loginpage.clickOnSignInButton();
		
	}
	/**
	 * Verify the login page with Invalid username and password
	 *
	 */
	@Test(priority = 2)
	public void ValidateHomepage() {

		homepage.assertHomePageTitle();
		homepage.MovetoRecruitment();
		homepage.movetoCandidates();
		Testutil.TakeScreenshot("Home");
	}
	@Test(priority = 3)
	public void NavigatetoCand() {
		
		homepage.NavigatetoCandidates();
		candidate.assertLoginPageTitle();
		
	}
	@Test(priority = 4)
	public void Addcand() {
		
		candidate.ClickAddBtn();
		candidate.Adduser();
		candidate.AdduseBtn();
		
		
	}
	@Test(priority = 5)
	public void VerfAddcand() {
		candidate.clickCand();
		candidate.VerfAdduser();
		
		
	}
	
}
