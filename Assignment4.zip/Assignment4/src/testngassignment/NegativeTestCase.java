package testngassignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NegativeTestCase {
		
		public WebDriver driver;
		
	    @BeforeTest
		public void setUp() {
		//Set system path for browser driver 
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		//to open browser
	    System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");		
		driver = new ChromeDriver();		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.get("http://zero.webappsecurity.com/index.html");
		}
		
		@Test (groups= {"regression"})
		public void wrongValue()  {
			driver.findElement(By.id("signin_button")).click();
			driver.findElement(By.id("user_login")).sendKeys("username");
			driver.findElement(By.id("user_password")).sendKeys("password");
			driver.findElement(By.name("submit")).click();
			
			//To accept the privacy
	        driver.findElement(By.id("details-button")).click();
	        driver.findElement(By.id("proceed-link")).click();
	       
	        driver.findElement(By.linkText("Zero Bank")).click();
	        driver.findElement(By.id("feedback")).click();
	        driver.findElement(By.name("submit"));
	         
	        driver.findElement(By.cssSelector("i.icon-user")).click();
	        driver.findElement(By.id("logout_link")).click();
		}
	        
		@Test (groups= {"regression"})
		
	    public void wrongLogIn() {
			driver.findElement(By.id("signin_button")).click();
			driver.findElement(By.id("user_login")).sendKeys("username");
			driver.findElement(By.id("user_password")).sendKeys("password123");
			driver.findElement(By.name("submit")).click();
			System.out.println(By.xpath("//div[contains(text(),'Login and/or password are wrong.')]"));
		}
		
		@Test(groups= {"regression"})
		
	    public void wrongInput() throws InterruptedException {
			driver.findElement(By.id("signin_button")).click();
			driver.findElement(By.id("user_login")).sendKeys("username");
			driver.findElement(By.id("user_password")).sendKeys("password");
			driver.findElement(By.name("submit")).click();
			
			//To accept the privacy
	        driver.findElement(By.id("details-button")).click();
	        driver.findElement(By.id("proceed-link")).click();
	        
	        //Transfer funds
	        driver.findElement(By.linkText("Transfer Funds")).click();
	        
	        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	        driver.findElement(By.id("tf_amount")).sendKeys("123");
	        driver.findElement(By.id("btn_submit")).click();
	        
		}
		
	        //Logout
		
		    @AfterTest
		    public void logOut() {
	        driver.findElement(By.cssSelector("i.icon-user")).click();
	        driver.findElement(By.id("logout_link")).click();
	        System.out.println("Signed out successfully");
	        
	        driver.close();
	        driver.quit();
		    }
		
}
