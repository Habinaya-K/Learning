package testngassignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FundTransfer {

	public WebDriver driver;
	
    @BeforeTest
	public void setUp() {
	//Set system path for browser driver 
	System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
	
	//to open browser
    System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");		
	driver = new ChromeDriver();		
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	driver.get("http://zero.webappsecurity.com/index.html");
	}
	
	@Test(groups= {"smoke"})
	
    public void fundTransfer() {

		//1. Purchase Foreign currency
		driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.id("user_login")).sendKeys("username");
		driver.findElement(By.id("user_password")).sendKeys("password");
		driver.findElement(By.name("submit")).click();
		
		//To accept the privacy
        driver.findElement(By.id("details-button")).click();
        driver.findElement(By.id("proceed-link")).click();
        
        //Transfer funds flow
        driver.findElement(By.linkText("Transfer Funds")).click();
        
        //Selecting from drop-down
        WebElement fromAcc = driver.findElement(By.id("tf_fromAccountId"));
        Select selFrom = new Select(fromAcc);
        selFrom.selectByIndex(2);
        
        WebElement toAcc = driver.findElement(By.id("tf_fromAccountId"));
        Select selTo = new Select(toAcc);
        selTo.selectByIndex(5);

        driver.findElement(By.id("tf_amount")).sendKeys("20");
        driver.findElement(By.id("tf_description")).sendKeys("New Test");
        driver.findElement(By.id("btn_submit")).click();
        driver.findElement(By.id("btn_submit")).click();
	    }
        
        //Logout
	    @AfterTest
	    public void logOut() {
        driver.findElement(By.cssSelector("i.icon-user")).click();
        driver.findElement(By.id("logout_link")).click();
        System.out.println("Signed out successfully");
        
        driver.close();
        driver.quit();
	    }

}
