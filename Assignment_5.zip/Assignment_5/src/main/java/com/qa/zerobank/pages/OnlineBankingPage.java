package com.qa.zerobank.pages;

public class OnlineBankingPage {

}
