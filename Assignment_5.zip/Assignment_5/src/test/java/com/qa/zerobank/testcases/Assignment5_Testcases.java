package com.qa.zerobank.testcases;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.zerobank.base.BaseTest;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.PayBillsPage;
import com.qa.zerobank.pages.TransferFundsPage;
import com.qa.zerobank.util.Testutil;

public class Assignment5_Testcases extends BaseTest {
	HomePage homepage;
	LogInPage loginpage;
	AccountSummaryPage accountsummarypage;
	PayBillsPage paybillspage;
	TransferFundsPage transferfundspage;
	Testutil testutil;

	public Assignment5_Testcases() {
		super();

	}

	@BeforeTest
	public void setup() {
		initialization();
		homepage = new HomePage();
		loginpage = new LogInPage();
		accountsummarypage = new AccountSummaryPage();
		paybillspage = new PayBillsPage();
		transferfundspage = new TransferFundsPage();
		testutil = new Testutil();
	}

	@AfterTest
	public void quit() {
		Testutil.TakeScreenshot("HomePage");
		driver.close();
		driver.quit();

	}

	@Test(priority = 0)
	public void ValidateHomePage() {
		homepage.assertHomePageTitle();
		assertTrue(homepage.VerifyLogo());
		loginpage = homepage.clickOnSignInButton();
	}

	@Test(priority = 1, dataProvider = "WrongLoginDetails")
	public void ValidateLoginFunction(String sname, String Pass) {

		loginpage.assertHomePageTitle();
		loginpage.invalidLogin(sname, Pass);
	}

	@Test(priority = 2)
	public void LogintoApplication() {

		accountsummarypage = loginpage.loginPage();
		accountsummarypage.assertLoginPageTitle();
	}

	@Test(priority = 3)
	public void ValidatePayBills() {

		paybillspage = accountsummarypage.ClickPayBills();
		paybillspage.assertPayBillsPageTitle();
		paybillspage.Click_Purchase_Foreign_Currency_Tab();
		paybillspage.PurchaseForeignCurrencySection();
		paybillspage.PurchaseForeignCurrency_Alert();
	}
	@Test(priority = 4)
	public void ValidatePaySavePayee() {

		paybillspage.NegativePaySavedPayee();
	}
	
	@Test(priority = 5)
	public void ValidateTransferMoneyAndMakePayments() {
		transferfundspage = paybillspage.NavigateTransferFunds();
		transferfundspage.InvalidateTransferMoneyAndMakePayments();

	}
	@Test(priority = 6)
	public void TransferMoneyAndMakePayments() {
		transferfundspage.ValidateTransferMoneyAndMakePayments();

	}

	@DataProvider
	public Object[][] WrongLoginDetails() {

		return new Object[][] {

				new Object[] { "username123", "password@#$" }, { "username1", "password@" } };
	}
}
